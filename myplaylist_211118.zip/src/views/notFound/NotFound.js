export function NotFound({error}){
    return(
        <h1>{error}</h1>
    )
}